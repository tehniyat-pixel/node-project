(function (AssetCustomForm) {
	'use strict';

	function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

	var AssetCustomForm__default = /*#__PURE__*/_interopDefault(AssetCustomForm);

	AdminJS.UserComponents = {};
	AdminJS.UserComponents.AssetCustomForm = AssetCustomForm__default.default;

})(AssetCustomForm);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlcyI6WyJlbnRyeS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJBZG1pbkpTLlVzZXJDb21wb25lbnRzID0ge31cbmltcG9ydCBBc3NldEN1c3RvbUZvcm0gZnJvbSAnY29tcG9uZW50cy9Bc3NldEN1c3RvbUZvcm0nXG5BZG1pbkpTLlVzZXJDb21wb25lbnRzLkFzc2V0Q3VzdG9tRm9ybSA9IEFzc2V0Q3VzdG9tRm9ybSJdLCJuYW1lcyI6WyJBZG1pbkpTIiwiVXNlckNvbXBvbmVudHMiLCJBc3NldEN1c3RvbUZvcm0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Q0FBQUEsT0FBTyxDQUFDQyxjQUFjLEdBQUcsRUFBRTtDQUUzQkQsT0FBTyxDQUFDQyxjQUFjLENBQUNDLGVBQWUsR0FBR0EsZ0NBQWU7Ozs7OzsifQ==
