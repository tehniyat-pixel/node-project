import AssetCustomForm from './components/AssetCustomForm.jsx';

AdminJS.UserComponents = AdminJS.UserComponents || {};
AdminJS.UserComponents.AssetCustomForm = AssetCustomForm;