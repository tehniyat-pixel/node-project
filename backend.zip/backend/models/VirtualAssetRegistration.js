import { DataTypes, Model } from 'sequelize'

class VirtualAssetRegistration extends Model {
  // This is a virtual model used for custom AdminJS pages
}

export default VirtualAssetRegistration;